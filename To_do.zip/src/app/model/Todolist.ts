export class ToDoList {
  public title?: string;
  public task?: string;
  public date?: string;
  public time?: string;
  public priority?: string;
}
